from enum import Enum

class Position(Enum):
    root = 0
    InsidePoint = 1
    Leaf = 2
